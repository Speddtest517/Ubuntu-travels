import React from 'react';
import { ViewMode } from '../types';

interface HeaderProps {
  appName: string;
  navigate: (view: ViewMode) => void;
  currentView: ViewMode;
}

const NavLink: React.FC<{ onClick: () => void; isActive: boolean; children: React.ReactNode; className?: string }> = ({ onClick, isActive, children, className }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-150 ease-in-out
      ${isActive ? 'bg-teal-600 text-white' : 'text-gray-700 hover:bg-teal-500 hover:text-white'} ${className}`}
  >
    {children}
  </button>
);

const Header: React.FC<HeaderProps> = ({ appName, navigate, currentView }) => {
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <svg className="h-10 w-10 text-teal-600 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
              <path d="M2 17l10 5 10-5"></path>
              <path d="M2 12l10 5 10-5"></path>
            </svg>
            <h1 className="font-display text-3xl font-bold text-teal-700">{appName}</h1>
          </div>
          <nav className="flex space-x-4">
            <NavLink onClick={() => navigate(ViewMode.Destinations)} isActive={currentView === ViewMode.Destinations}>
              Destinos
            </NavLink>
            <NavLink onClick={() => navigate(ViewMode.About)} isActive={currentView === ViewMode.About}>
              Sobre Nós
            </NavLink>
            <NavLink onClick={() => navigate(ViewMode.Contact)} isActive={currentView === ViewMode.Contact}>
              Contacto
            </NavLink>
            <NavLink 
              onClick={() => navigate(ViewMode.AdminDashboard)} 
              isActive={currentView === ViewMode.AdminDashboard || currentView === ViewMode.AdminAppointments || currentView === ViewMode.AdminClients}
              className="text-red-600 hover:bg-red-500 hover:text-white"
            >
              Admin
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
