import React from 'react';

interface FooterProps {
  appName: string;
  tagline: string;
}

const Footer: React.FC<FooterProps> = ({ appName, tagline }) => {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <p>&copy; {new Date().getFullYear()} {appName}. Todos os direitos reservados.</p>
        <p className="text-sm text-gray-400 mt-1">{tagline}</p>
      </div>
    </footer>
  );
};

export default Footer;