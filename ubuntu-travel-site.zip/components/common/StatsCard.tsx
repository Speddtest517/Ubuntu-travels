import React from 'react';
import { Stat } from '../../types';

interface StatsCardProps {
  stat: Stat;
}

const StatsCard: React.FC<StatsCardProps> = ({ stat }) => {
  const { title, value, icon: Icon, change, changeType } = stat;

  let changeColorClass = '';
  if (changeType === 'positive') {
    changeColorClass = 'text-green-500';
  } else if (changeType === 'negative') {
    changeColorClass = 'text-red-500';
  }

  return (
    <div className="bg-white p-5 rounded-xl shadow-lg flex items-start space-x-4 transition-all hover:shadow-xl">
      {Icon && (
        <div className="flex-shrink-0 p-3 bg-teal-500 text-white rounded-full">
          <Icon className="h-6 w-6" />
        </div>
      )}
      <div>
        <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
        <p className="mt-1 text-3xl font-semibold text-gray-900">{value}</p>
        {change && (
          <p className={`text-sm font-medium ${changeColorClass} mt-1`}>
            {change}
          </p>
        )}
      </div>
    </div>
  );
};

export default StatsCard;
