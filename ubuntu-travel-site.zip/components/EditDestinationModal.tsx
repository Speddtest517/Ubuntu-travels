import React, { useState, useEffect, useCallback } from 'react';
import { Destination } from '../types';
import Modal from './common/Modal';
import Button from './common/Button';
import LoadingSpinner from './common/LoadingSpinner';

interface EditDestinationModalProps {
  isOpen: boolean;
  onClose: () => void;
  destination: Destination;
  onSave: (updatedDestination: Destination) => void;
  onGenerateDescription: (destinationName: string) => Promise<string>;
  isGenerating: boolean;
  generationError: string | null;
}

const WandIcon: React.FC<{className?: string}> = ({className}) => (
 <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5 mr-2"} viewBox="0 0 20 20" fill="currentColor">
  <path fillRule="evenodd" d="M3.5 2a.5.5 0 00-.5.5v15a.5.5 0 00.5.5h13a.5.5 0 00.5-.5v-15a.5.5 0 00-.5-.5h-13zM4 3h12v2.5H4V3zm0 3.5h12V17H4V6.5zm1.5-2a.5.5 0 000 1h9a.5.5 0 000-1h-9zM6 8a.5.5 0 01.5-.5h.5a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5H6.5a.5.5 0 01-.5-.5V8zm2.5 0A.5.5 0 019 7.5h2a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5H9a.5.5 0 01-.5-.5V8zm3.5 0a.5.5 0 01.5-.5h.5a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5h-.5a.5.5 0 01-.5-.5V8zM6 11a.5.5 0 01.5-.5h.5a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5H6.5a.5.5 0 01-.5-.5v-.5zm2.5 0a.5.5 0 01.5-.5h2a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5H9a.5.5 0 01-.5-.5v-.5zm3.5 0a.5.5 0 01.5-.5h.5a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5h-.5a.5.5 0 01-.5-.5v-.5zm-6 3a.5.5 0 01.5-.5h5a.5.5 0 01.5.5v.5a.5.5 0 01-.5.5h-5a.5.5 0 01-.5-.5v-.5z" clipRule="evenodd" />
  <path d="M5.646 4.146a.5.5 0 01.708 0L8 5.793l1.646-1.647a.5.5 0 11.708.708L8.707 6.5l1.647 1.646a.5.5 0 11-.708.708L8 7.207 6.354 8.854a.5.5 0 11-.708-.708L7.293 6.5 5.646 4.854a.5.5 0 010-.708zM2.5 0A2.5 2.5 0 000 2.5V3h1.5a.5.5 0 01.5.5v10a.5.5 0 01-.5.5H0v.5A2.5 2.5 0 002.5 19h8a.5.5 0 00.5-.5V3.5a.5.5 0 00-.5-.5h-8A2.5 2.5 0 00.5 0H2.5z" />
 </svg>
);


const EditDestinationModal: React.FC<EditDestinationModalProps> = ({
  isOpen,
  onClose,
  destination,
  onSave,
  onGenerateDescription,
  isGenerating,
  generationError,
}) => {
  const [name, setName] = useState(destination.name);
  const [country, setCountry] = useState(destination.country);
  const [description, setDescription] = useState(destination.description); // Short description
  const [longDescription, setLongDescription] = useState(destination.longDescription); // Long description
  const [category, setCategory] = useState(destination.category);
  const [imageUrl, setImageUrl] = useState(destination.imageUrl); // New state for image URL

  useEffect(() => {
    setName(destination.name);
    setCountry(destination.country);
    setDescription(destination.description);
    setLongDescription(destination.longDescription);
    setCategory(destination.category);
    setImageUrl(destination.imageUrl); // Update imageUrl on destination change
  }, [destination]);
  
  const handleDescriptionChange = useCallback((newDescription: string) => {
    setLongDescription(newDescription);
  }, []);

  useEffect(() => {
    if (isGenerating === false && destination.longDescription !== longDescription ) {
       setLongDescription(destination.longDescription);
    }
  }, [destination.longDescription, isGenerating, longDescription]);


  const handleSaveClick = () => {
    onSave({ ...destination, name, country, description, longDescription, category, imageUrl }); // Include imageUrl in save
  };

  const handleGenerateClick = async () => {
     await onGenerateDescription(name);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Editar ${destination.name}`}>
      <div className="space-y-4">
        <div>
          <label htmlFor="dest-name" className="block text-sm font-medium text-gray-700">Nome</label>
          <input
            type="text"
            id="dest-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="dest-country" className="block text-sm font-medium text-gray-700">País</label>
          <input
            type="text"
            id="dest-country"
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
         <div>
          <label htmlFor="dest-category" className="block text-sm font-medium text-gray-700">Categoria</label>
          <input
            type="text"
            id="dest-category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="dest-image-url" className="block text-sm font-medium text-gray-700">URL da Imagem</label>
          <input
            type="url"
            id="dest-image-url"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="dest-short-desc" className="block text-sm font-medium text-gray-700">Descrição Curta (para o cartão)</label>
          <textarea
            id="dest-short-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="dest-long-desc" className="block text-sm font-medium text-gray-700">Descrição Longa</label>
          <textarea
            id="dest-long-desc"
            value={longDescription}
            onChange={(e) => handleDescriptionChange(e.target.value)}
            rows={6}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
        {generationError && <p className="text-sm text-red-600">{generationError}</p>}
        <Button 
          onClick={handleGenerateClick} 
          disabled={isGenerating}
          className="w-full bg-sky-600 hover:bg-sky-700 text-white flex items-center justify-center"
        >
          {isGenerating ? <LoadingSpinner size="small" /> : <WandIcon />}
          {isGenerating ? 'A Gerar...' : 'Gerar Descrição Longa com IA'}
        </Button>
      </div>
      <div className="mt-6 flex justify-end space-x-3">
        <Button onClick={onClose} variant="secondary">
          Cancelar
        </Button>
        <Button onClick={handleSaveClick}>
          Guardar Alterações
        </Button>
      </div>
    </Modal>
  );
};

export default EditDestinationModal;