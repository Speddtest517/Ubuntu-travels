import React from 'react';
import { Destination } from '../types';
import Button from './common/Button';

interface DestinationCardProps {
  destination: Destination;
  onEdit: (destination: Destination) => void;
}

const PencilIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className || "h-5 w-5 mr-2"} viewBox="0 0 20 20" fill="currentColor">
    <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
    <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
  </svg>
);


const DestinationCard: React.FC<DestinationCardProps> = ({ destination, onEdit }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 ease-in-out hover:shadow-2xl flex flex-col">
      <div className="relative h-56">
        <img 
          className="w-full h-full object-cover" 
          src={destination.imageUrl} 
          alt={`Vista de ${destination.name}`} 
        />
        <div className="absolute top-0 right-0 bg-teal-600 text-white px-3 py-1 text-sm font-semibold rounded-bl-lg">
          {destination.category}
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="font-display text-2xl font-bold text-gray-800 mb-1">{destination.name}</h3>
        <p className="text-md text-teal-700 font-medium mb-3">{destination.country}</p>
        <p className="text-gray-600 text-sm mb-4 flex-grow">{destination.description}</p>
        <Button 
          onClick={() => onEdit(destination)} 
          className="w-full bg-slate-700 hover:bg-slate-800 text-white"
        >
          <PencilIcon />
          Editar Detalhes
        </Button>
      </div>
    </div>
  );
};

export default DestinationCard;