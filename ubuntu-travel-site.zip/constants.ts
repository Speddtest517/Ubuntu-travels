import { Destination, HeroContentConfig, AboutContentConfig, ContactContentConfig, FooterContentConfig } from './types';

export const DEFAULT_DESTINATIONS: Destination[] = [
  {
    id: '1',
    name: 'Lisboa',
    country: 'Portugal',
    description: 'Charme histórico encontra cultura vibrante.',
    longDescription: 'Lisboa, a cativante capital de Portugal, encanta os visitantes com seus bairros históricos, arquitetura deslumbrante, música de Fado vibrante e deliciosos pastéis de nata. Explore o Castelo de São Jorge, apanhe o icónico Elétrico 28 e desfrute de vistas panorâmicas de um "miradouro".',
    imageUrl: 'https://picsum.photos/seed/lisbon/600/400',
    category: 'Europa',
  },
  {
    id: '2',
    name: 'Paris',
    country: 'França',
    description: 'A cidade das luzes, romance e arte.',
    longDescription: 'Paris, o epítome do romance e da cultura, ostenta marcos icónicos como a Torre Eiffel e o Museu do Louvre. Passeie ao longo do Sena, delicie-se com a culinária requintada e mergulhe na sua atmosfera artística.',
    imageUrl: 'https://picsum.photos/seed/paris/600/400',
    category: 'Europa',
  },
  {
    id: '3',
    name: 'Londres',
    country: 'Inglaterra',
    description: 'Uma metrópole movimentada com rica história.',
    longDescription: 'Londres, um centro global de história, cultura e inovação, oferece inúmeras atrações, desde a Torre de Londres ao Palácio de Buckingham. Desfrute de teatro de classe mundial, museus diversos e mercados vibrantes.',
    imageUrl: 'https://picsum.photos/seed/london/600/400',
    category: 'Europa',
  },
  {
    id: '4',
    name: 'Vancouver',
    country: 'Canadá',
    description: 'Natureza deslumbrante encontra sofisticação urbana.',
    longDescription: 'Vancouver, aninhada entre montanhas e o oceano, é renomada pela sua beleza natural e atividades ao ar livre. Explore o Stanley Park, Granville Island e desfrute da vibração multicultural da cidade.',
    imageUrl: 'https://picsum.photos/seed/vancouver/600/400',
    category: 'América do Norte',
  },
   {
    id: '5',
    name: 'Quioto',
    country: 'Japão',
    description: 'Templos antigos e jardins serenos.',
    longDescription: 'Quioto, a antiga capital imperial do Japão, é uma cidade de templos encantadores, jardins serenos, casas de chá tradicionais e distritos de gueixas. Descubra o Kinkaku-ji (Pavilhão Dourado) e o Santuário Fushimi Inari.',
    imageUrl: 'https://picsum.photos/seed/kyoto/600/400',
    category: 'Ásia',
  },
  {
    id: '6',
    name: 'Roma',
    country: 'Itália',
    description: 'Cidade eterna de história e massa.',
    longDescription: 'Roma, a Cidade Eterna, é um tesouro de ruínas antigas como o Coliseu e o Fórum Romano, arte magnífica e a Cidade do Vaticano. Delicie-se com a autêntica culinária italiana e jogue uma moeda na Fontana di Trevi.',
    imageUrl: 'https://picsum.photos/seed/rome/600/400',
    category: 'Europa',
  }
];

export const APP_NAME = "Ubuntu Travel";

export const INITIAL_HERO_CONTENT: HeroContentConfig = {
  title: "Descubra a Sua Próxima Aventura",
  subtitle: "Explore destinos deslumbrantes com a Ubuntu Travel. Experiências personalizadas esperam por si.",
  imageUrl: "https://picsum.photos/seed/hero/1920/600",
};

export const INITIAL_ABOUT_CONTENT: AboutContentConfig = {
  paragraph1: `Na <span class="font-semibold text-teal-700">${APP_NAME}</span>, acreditamos que viajar é mais do que apenas visitar novos lugares; é sobre criar memórias duradouras, promover conexões e experienciar as diversas culturas do mundo. O nome "Ubuntu" reflete a nossa filosofia – "Eu sou porque nós somos" – enfatizando comunidade, conexão e experiências partilhadas.`,
  paragraph2: "A nossa missão é fornecer planeamento de viagens personalizado e integrado. Desde refúgios exóticos em praias a caminhadas aventureiras em montanhas e passeios culturais ricos pela cidade, a nossa equipa de especialistas dedica-se a desenhar a sua jornada perfeita. Nós tratamos de todos os detalhes, para que se possa concentrar em aproveitar a aventura.",
  valuesIntro: "Os Nossos Valores",
  valueItems: [
    { title: "Foco no Cliente", description: "A sua satisfação é a nossa principal prioridade." },
    { title: "Autenticidade", description: "Oferecemos experiências genuínas que o conectam com as culturas locais." },
    { title: "Excelência", description: "Esforçamo-nos pelos mais altos padrões de serviço e qualidade." },
    { title: "Sustentabilidade", description: "Promovemos práticas de viagem responsáveis." },
  ],
  imageUrl: "https://picsum.photos/seed/aboutus/600/450",
};

export const INITIAL_CONTACT_CONTENT: ContactContentConfig = {
  introText: "Tem perguntas ou está pronto para planear a sua próxima aventura? Adoraríamos ouvir de si!",
  email: "contact@ubuntutravel.com",
  phone: "+1 (234) 567-890",
};

export const INITIAL_FOOTER_CONTENT: FooterContentConfig = {
  tagline: "Criando viagens inesquecíveis.",
};