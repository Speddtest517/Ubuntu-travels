export interface Destination {
  id: string;
  name: string;
  country: string;
  description: string;
  longDescription: string;
  imageUrl: string;
  category: string; // e.g., Europe, North America
}

export enum ViewMode {
  Destinations,
  About,
  Contact,
  AdminDashboard,
  AdminAppointments,
  AdminClients,
  AdminSiteContent, // Novo modo de visualização
}

export interface Stat {
  title: string;
  value: string | number;
  icon?: React.ElementType;
  change?: string; // e.g., "+5%"
  changeType?: 'positive' | 'negative';
}

export interface HeroContentConfig {
  title: string;
  subtitle: string;
  imageUrl: string;
}

export interface AboutContentConfig {
  paragraph1: string;
  paragraph2: string;
  valuesIntro: string;
  valueItems: { title: string, description: string }[];
  imageUrl: string;
}

export interface ContactContentConfig {
  introText: string;
  email: string;
  phone: string;
}

export interface FooterContentConfig {
  tagline: string;
}