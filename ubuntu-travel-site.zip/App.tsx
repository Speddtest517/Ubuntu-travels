import React, { useState, useCallback } from 'react';
import { Destination, ViewMode, HeroContentConfig, AboutContentConfig, ContactContentConfig, FooterContentConfig } from './types';
import { DEFAULT_DESTINATIONS, APP_NAME, INITIAL_HERO_CONTENT, INITIAL_ABOUT_CONTENT, INITIAL_CONTACT_CONTENT, INITIAL_FOOTER_CONTENT } from './constants';
import Header from './components/Header';
import Footer from './components/Footer';
import HeroSection from './sections/HeroSection';
import DestinationsSection from './sections/DestinationsSection';
import EditDestinationModal from './components/EditDestinationModal';
import { generateDestinationDescription as fetchGeneratedDescription } from './services/geminiService';
import AboutSection from './sections/AboutSection';
import ContactSection from './sections/ContactSection';
import AdminPanel from './sections/admin/AdminPanel';

const App: React.FC = () => {
  const [destinations, setDestinations] = useState<Destination[]>(DEFAULT_DESTINATIONS);
  const [editingDestination, setEditingDestination] = useState<Destination | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.Destinations);

  // State for editable site content
  const [heroContent, setHeroContent] = useState<HeroContentConfig>(INITIAL_HERO_CONTENT);
  const [aboutContent, setAboutContent] = useState<AboutContentConfig>(INITIAL_ABOUT_CONTENT);
  const [contactContent, setContactContent] = useState<ContactContentConfig>(INITIAL_CONTACT_CONTENT);
  const [footerContent, setFooterContent] = useState<FooterContentConfig>(INITIAL_FOOTER_CONTENT);

  const handleEditDestination = useCallback((destination: Destination) => {
    setEditingDestination(destination);
    setIsModalOpen(true);
    setError(null);
  }, []);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setEditingDestination(null);
    setError(null);
  }, []);

  const handleSaveDestination = useCallback((updatedDestination: Destination) => {
    setDestinations(prevDestinations =>
      prevDestinations.map(dest => (dest.id === updatedDestination.id ? updatedDestination : dest))
    );
    handleCloseModal();
  }, [handleCloseModal]);

  const handleAddDestination = useCallback((newDestination: Destination) => {
    setDestinations(prevDestinations => [...prevDestinations, { ...newDestination, id: String(Date.now()) }]); // Simple ID generation
  }, []);

  const handleDeleteDestination = useCallback((destinationId: string) => {
    setDestinations(prevDestinations => prevDestinations.filter(dest => dest.id !== destinationId));
  }, []);


  const handleGenerateDescription = useCallback(async (destinationName: string): Promise<string> => {
    setIsGenerating(true);
    setError(null);
    try {
      const description = await fetchGeneratedDescription(destinationName, editingDestination?.country || '');
      if (editingDestination) {
        setEditingDestination(prev => prev ? {...prev, longDescription: description} : null);
      }
      setIsGenerating(false);
      return description;
    } catch (err) {
      console.error('Error generating description:', err);
      const errorMessage = err instanceof Error ? err.message : 'Falha ao gerar descrição.';
      setError(errorMessage);
      setIsGenerating(false);
      return editingDestination?.longDescription || ''; // return current description on error
    }
  }, [editingDestination]);

  const navigate = (view: ViewMode) => {
    setCurrentView(view);
  };

  const isAdminView = currentView === ViewMode.AdminDashboard || 
                      currentView === ViewMode.AdminAppointments || 
                      currentView === ViewMode.AdminClients ||
                      currentView === ViewMode.AdminSiteContent;

  if (isAdminView) {
    return (
      <AdminPanel 
        currentView={currentView} 
        navigate={navigate} 
        appName={APP_NAME} 
        totalDestinations={destinations.length}
        // Pass content states and setters
        heroContent={heroContent}
        setHeroContent={setHeroContent}
        aboutContent={aboutContent}
        setAboutContent={setAboutContent}
        contactContent={contactContent}
        setContactContent={setContactContent}
        footerContent={footerContent}
        setFooterContent={setFooterContent}
        destinations={destinations}
        onAddDestination={handleAddDestination}
        onUpdateDestination={handleSaveDestination} // Alias for clarity in Admin
        onDeleteDestination={handleDeleteDestination}
        onEditDestination={handleEditDestination} // To open the modal from admin
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-100">
      <Header appName={APP_NAME} navigate={navigate} currentView={currentView} />
      
      <main className="flex-grow">
        {currentView === ViewMode.Destinations && (
          <>
            <HeroSection 
              title={heroContent.title}
              subtitle={heroContent.subtitle}
              imageUrl={heroContent.imageUrl}
            />
            <DestinationsSection
              destinations={destinations}
              onEditDestination={handleEditDestination}
            />
          </>
        )}
        {currentView === ViewMode.About && <AboutSection content={aboutContent} appName={APP_NAME} />}
        {currentView === ViewMode.Contact && <ContactSection content={contactContent} />}
      </main>

      {isModalOpen && editingDestination && (
        <EditDestinationModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          destination={editingDestination}
          onSave={handleSaveDestination}
          onGenerateDescription={handleGenerateDescription}
          isGenerating={isGenerating}
          generationError={error}
        />
      )}
      <Footer appName={APP_NAME} tagline={footerContent.tagline} />
    </div>
  );
};

export default App;