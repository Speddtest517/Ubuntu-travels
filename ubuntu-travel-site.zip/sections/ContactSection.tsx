import React, { useState } from 'react';
import Button from '../components/common/Button';
import { ContactContentConfig } from '../types';

interface ContactSectionProps {
  content: ContactContentConfig;
}

const ContactSection: React.FC<ContactSectionProps> = ({ content }) => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitError(null);
    setIsSubmitted(false); // Reset submission status

    // Basic client-side validation example
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
        setSubmitError("Por favor, preencha todos os campos obrigatórios.");
        return;
    }
    if (!/\S+@\S+\.\S+/.test(formData.email)) {
        setSubmitError("Por favor, insira um endereço de email válido.");
        return;
    }

    // Simulate API call
    try {
      // Replace with actual API call:
      // await api.submitContactForm(formData); 
      console.log('Formulário submetido:', formData);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
      
      setIsSubmitted(true);
      setFormData({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setIsSubmitted(false), 5000); // Reset message after 5 seconds
    } catch (error) {
        console.error("Erro ao submeter formulário:", error);
        setSubmitError("Ocorreu um erro ao enviar a sua mensagem. Por favor, tente novamente mais tarde.");
    }
  };


  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-gray-800">Entre em Contacto</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-xl mx-auto">
            {content.introText}
          </p>
        </div>
        <div className="max-w-2xl mx-auto bg-white p-8 sm:p-10 rounded-xl shadow-xl">
          {isSubmitted && (
            <div className="text-center py-8">
              <svg className="w-16 h-16 mx-auto text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
              <h3 className="mt-4 text-2xl font-semibold text-gray-800">Obrigado!</h3>
              <p className="mt-2 text-gray-600">A sua mensagem foi enviada com sucesso. Entraremos em contacto em breve.</p>
            </div>
          )}
          {submitError && !isSubmitted && (
             <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-md">
                <p>{submitError}</p>
            </div>
          )}
          {!isSubmitted && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nome Completo <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Endereço de Email <span className="text-red-500">*</span></label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
                />
              </div>
               <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700">Assunto <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="subject"
                  id="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Mensagem <span className="text-red-500">*</span></label>
                <textarea
                  name="message"
                  id="message"
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
                ></textarea>
              </div>
              <div>
                <Button type="submit" className="w-full">
                  Enviar Mensagem
                </Button>
              </div>
            </form>
          )}
          <div className="mt-10 text-center border-t pt-8">
            <h3 className="text-xl font-semibold text-gray-800 mb-3">Outras Formas de Contacto</h3>
            <p className="text-gray-600">Email: <a href={`mailto:${content.email}`} className="text-teal-600 hover:text-teal-700">{content.email}</a></p>
            <p className="text-gray-600">Telefone: <a href={`tel:${content.phone.replace(/\s/g, '')}`} className="text-teal-600 hover:text-teal-700">{content.phone}</a></p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;