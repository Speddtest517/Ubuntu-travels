import React from 'react';
import { ViewMode } from '../../types';

interface AdminHeaderProps {
  appName: string;
  navigate: (view: ViewMode) => void;
}

const UserIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className || "h-6 w-6"} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const LogoutIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className || "h-5 w-5 mr-2"} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
  </svg>
);


const AdminHeader: React.FC<AdminHeaderProps> = ({ appName, navigate }) => {
  return (
    <header className="bg-slate-800 text-white shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
             <svg className="h-8 w-8 text-teal-400 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
              <path d="M2 17l10 5 10-5"></path>
              <path d="M2 12l10 5 10-5"></path>
            </svg>
            <h1 className="font-display text-xl font-bold text-white">{appName} - Painel Admin</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => navigate(ViewMode.Destinations)} 
              className="flex items-center text-sm text-slate-300 hover:text-white transition-colors"
              title="Voltar ao Site Público"
              aria-label="Voltar ao Site Público"
            >
              <LogoutIcon className="h-5 w-5 mr-1" />
              Sair do Admin
            </button>
            <div className="flex items-center">
              <span className="text-sm text-slate-300 mr-2 hidden sm:inline">Admin User</span>
              <UserIcon className="h-8 w-8 text-slate-400" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;
