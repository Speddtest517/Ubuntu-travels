import React from 'react';
import { ViewMode, HeroContentConfig, AboutContentConfig, ContactContentConfig, FooterContentConfig, Destination } from '../../types';
import AdminHeader from './AdminHeader';
import AdminSidebar from './AdminSidebar';
import AdminDashboard from './AdminDashboard';
import AdminAppointmentsPage from './AdminAppointmentsPage';
import AdminClientsPage from './AdminClientsPage';
import AdminSiteContentPage from './AdminSiteContentPage'; // Novo import

interface AdminPanelProps {
  currentView: ViewMode;
  navigate: (view: ViewMode) => void;
  appName: string;
  totalDestinations: number;
  // Props para gerenciamento de conteúdo do site
  heroContent: HeroContentConfig;
  setHeroContent: React.Dispatch<React.SetStateAction<HeroContentConfig>>;
  aboutContent: AboutContentConfig;
  setAboutContent: React.Dispatch<React.SetStateAction<AboutContentConfig>>;
  contactContent: ContactContentConfig;
  setContactContent: React.Dispatch<React.SetStateAction<ContactContentConfig>>;
  footerContent: FooterContentConfig;
  setFooterContent: React.Dispatch<React.SetStateAction<FooterContentConfig>>;
  destinations: Destination[];
  onAddDestination: (destination: Destination) => void;
  onUpdateDestination: (destination: Destination) => void;
  onDeleteDestination: (id: string) => void;
  onEditDestination: (destination: Destination) => void; // Para abrir o modal de edição
}

const AdminPanel: React.FC<AdminPanelProps> = (props) => {
  const { 
    currentView, navigate, appName, totalDestinations,
    heroContent, setHeroContent, aboutContent, setAboutContent,
    contactContent, setContactContent, footerContent, setFooterContent,
    destinations, onAddDestination, onUpdateDestination, onDeleteDestination,
    onEditDestination
  } = props;

  const renderContent = () => {
    switch (currentView) {
      case ViewMode.AdminDashboard:
        return <AdminDashboard totalDestinations={totalDestinations} />;
      case ViewMode.AdminAppointments:
        return <AdminAppointmentsPage />;
      case ViewMode.AdminClients:
        return <AdminClientsPage />;
      case ViewMode.AdminSiteContent:
        return (
          <AdminSiteContentPage
            heroContent={heroContent}
            setHeroContent={setHeroContent}
            aboutContent={aboutContent}
            setAboutContent={setAboutContent}
            contactContent={contactContent}
            setContactContent={setContactContent}
            footerContent={footerContent}
            setFooterContent={setFooterContent}
            destinations={destinations}
            onAddDestination={onAddDestination}
            onUpdateDestination={onUpdateDestination}
            onDeleteDestination={onDeleteDestination}
            onEditDestination={onEditDestination}
          />
        );
      default:
        return <AdminDashboard totalDestinations={totalDestinations} />; // Fallback to dashboard
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <AdminHeader appName={appName} navigate={navigate} />
      <div className="flex flex-1" style={{maxHeight: 'calc(100vh - 4rem)'}}> {/* 4rem é a altura do header */}
        <AdminSidebar currentView={currentView} navigate={navigate} />
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;