import React, { useState } from 'react';
import { HeroContentConfig, AboutContentConfig, ContactContentConfig, FooterContentConfig, Destination } from '../../types';
import Button from '../../components/common/Button';

interface AdminSiteContentPageProps {
  heroContent: HeroContentConfig;
  setHeroContent: React.Dispatch<React.SetStateAction<HeroContentConfig>>;
  aboutContent: AboutContentConfig;
  setAboutContent: React.Dispatch<React.SetStateAction<AboutContentConfig>>;
  contactContent: ContactContentConfig;
  setContactContent: React.Dispatch<React.SetStateAction<ContactContentConfig>>;
  footerContent: FooterContentConfig;
  setFooterContent: React.Dispatch<React.SetStateAction<FooterContentConfig>>;
  destinations: Destination[];
  onAddDestination: (destination: Destination) => void;
  onUpdateDestination: (destination: Destination) => void; // Usado pelo modal que será aberto por onEditDestination
  onDeleteDestination: (id: string) => void;
  onEditDestination: (destination: Destination) => void; // Para abrir o modal de edição
}

const AdminSiteContentPage: React.FC<AdminSiteContentPageProps> = ({
  heroContent, setHeroContent,
  aboutContent, setAboutContent,
  contactContent, setContactContent,
  footerContent, setFooterContent,
  destinations, onAddDestination, onDeleteDestination, onEditDestination
}) => {
  
  // Local state for forms
  const [localHero, setLocalHero] = useState(heroContent);
  const [localAbout, setLocalAbout] = useState(aboutContent);
  const [localContact, setLocalContact] = useState(contactContent);
  const [localFooter, setLocalFooter] = useState(footerContent);

  const [newDestination, setNewDestination] = useState<Omit<Destination, 'id'>>({
    name: '', country: '', description: '', longDescription: '', imageUrl: '', category: ''
  });

  const handleHeroChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setLocalHero({ ...localHero, [e.target.name]: e.target.value });
  };
  const handleAboutChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setLocalAbout({ ...localAbout, [e.target.name]: e.target.value });
  };
  const handleContactChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setLocalContact({ ...localContact, [e.target.name]: e.target.value });
  };
  const handleFooterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setLocalFooter({ ...localFooter, [e.target.name]: e.target.value });
  };
  
  const handleNewDestinationChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setNewDestination({ ...newDestination, [e.target.name]: e.target.value });
  };

  const handleSaveHero = () => setHeroContent(localHero);
  const handleSaveAbout = () => setAboutContent(localAbout);
  const handleSaveContact = () => setContactContent(localContact);
  const handleSaveFooter = () => setFooterContent(localFooter);

  const handleAddNewDestination = (e: React.FormEvent) => {
    e.preventDefault();
    if (newDestination.name && newDestination.country && newDestination.description && newDestination.imageUrl && newDestination.category) {
      onAddDestination(newDestination as Destination); // Cast because ID will be added by parent
      setNewDestination({ name: '', country: '', description: '', longDescription: '', imageUrl: '', category: '' }); // Reset form
    } else {
      alert("Por favor, preencha todos os campos obrigatórios para adicionar um novo destino.");
    }
  };
  
  const inputClass = "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm";
  const textareaClass = "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm resize-y";
  const labelClass = "block text-sm font-medium text-gray-700";
  const sectionClass = "bg-white p-6 rounded-lg shadow mb-8";
  const sectionTitleClass = "text-xl font-semibold text-gray-800 mb-4 font-display";

  return (
    <div>
      <h2 className="font-display text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Gerenciar Conteúdo do Site</h2>

      {/* Hero Section Content */}
      <div className={sectionClass}>
        <h3 className={sectionTitleClass}>Conteúdo da Seção Hero</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="heroTitle" className={labelClass}>Título</label>
            <input type="text" name="title" id="heroTitle" value={localHero.title} onChange={handleHeroChange} className={inputClass} />
          </div>
          <div>
            <label htmlFor="heroSubtitle" className={labelClass}>Subtítulo</label>
            <textarea name="subtitle" id="heroSubtitle" value={localHero.subtitle} onChange={handleHeroChange} className={textareaClass} rows={3} />
          </div>
          <div>
            <label htmlFor="heroImageUrl" className={labelClass}>URL da Imagem de Fundo</label>
            <input type="url" name="imageUrl" id="heroImageUrl" value={localHero.imageUrl} onChange={handleHeroChange} className={inputClass} />
          </div>
          <Button onClick={handleSaveHero}>Guardar Seção Hero</Button>
        </div>
      </div>

      {/* About Section Content */}
      <div className={sectionClass}>
        <h3 className={sectionTitleClass}>Conteúdo da Seção Sobre Nós</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="aboutP1" className={labelClass}>Parágrafo 1</label>
            <textarea name="paragraph1" id="aboutP1" value={localAbout.paragraph1} onChange={handleAboutChange} className={textareaClass} rows={4} />
          </div>
          <div>
            <label htmlFor="aboutP2" className={labelClass}>Parágrafo 2</label>
            <textarea name="paragraph2" id="aboutP2" value={localAbout.paragraph2} onChange={handleAboutChange} className={textareaClass} rows={4} />
          </div>
          {/* Values Intro and Items could be made editable here as well, if needed */}
          <div>
            <label htmlFor="aboutImageUrl" className={labelClass}>URL da Imagem</label>
            <input type="url" name="imageUrl" id="aboutImageUrl" value={localAbout.imageUrl} onChange={handleAboutChange} className={inputClass} />
          </div>
          <Button onClick={handleSaveAbout}>Guardar Seção Sobre Nós</Button>
        </div>
      </div>
      
      {/* Contact Section Content */}
      <div className={sectionClass}>
        <h3 className={sectionTitleClass}>Conteúdo da Seção de Contacto</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="contactIntro" className={labelClass}>Texto Introdutório</label>
            <textarea name="introText" id="contactIntro" value={localContact.introText} onChange={handleContactChange} className={textareaClass} rows={3}/>
          </div>
           <div>
            <label htmlFor="contactEmail" className={labelClass}>Email de Contacto</label>
            <input type="email" name="email" id="contactEmail" value={localContact.email} onChange={handleContactChange} className={inputClass} />
          </div>
           <div>
            <label htmlFor="contactPhone" className={labelClass}>Telefone de Contacto</label>
            <input type="tel" name="phone" id="contactPhone" value={localContact.phone} onChange={handleContactChange} className={inputClass} />
          </div>
          <Button onClick={handleSaveContact}>Guardar Seção de Contacto</Button>
        </div>
      </div>

      {/* Footer Content */}
       <div className={sectionClass}>
        <h3 className={sectionTitleClass}>Conteúdo do Rodapé</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="footerTagline" className={labelClass}>Tagline</label>
            <input type="text" name="tagline" id="footerTagline" value={localFooter.tagline} onChange={handleFooterChange} className={inputClass} />
          </div>
          <Button onClick={handleSaveFooter}>Guardar Rodapé</Button>
        </div>
      </div>

      {/* Destinations Management */}
      <div className={sectionClass}>
        <h3 className={sectionTitleClass}>Gerenciar Destinos</h3>
        <form onSubmit={handleAddNewDestination} className="mb-6 p-4 border border-gray-200 rounded-md space-y-3">
          <h4 className="text-md font-semibold text-gray-700">Adicionar Novo Destino</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="destName" className={labelClass}>Nome do Destino <span className="text-red-500">*</span></label>
              <input type="text" name="name" id="destName" value={newDestination.name} onChange={handleNewDestinationChange} className={inputClass} required />
            </div>
            <div>
              <label htmlFor="destCountry" className={labelClass}>País <span className="text-red-500">*</span></label>
              <input type="text" name="country" id="destCountry" value={newDestination.country} onChange={handleNewDestinationChange} className={inputClass} required />
            </div>
            <div>
              <label htmlFor="destCategory" className={labelClass}>Categoria <span className="text-red-500">*</span></label>
              <input type="text" name="category" id="destCategory" value={newDestination.category} onChange={handleNewDestinationChange} className={inputClass} required />
            </div>
             <div>
              <label htmlFor="destImageUrl" className={labelClass}>URL da Imagem <span className="text-red-500">*</span></label>
              <input type="url" name="imageUrl" id="destImageUrl" value={newDestination.imageUrl} onChange={handleNewDestinationChange} className={inputClass} required />
            </div>
          </div>
          <div>
            <label htmlFor="destShortDesc" className={labelClass}>Descrição Curta <span className="text-red-500">*</span></label>
            <textarea name="description" id="destShortDesc" value={newDestination.description} onChange={handleNewDestinationChange} className={textareaClass} rows={2} required />
          </div>
          <div>
            <label htmlFor="destLongDesc" className={labelClass}>Descrição Longa</label>
            <textarea name="longDescription" id="destLongDesc" value={newDestination.longDescription} onChange={handleNewDestinationChange} className={textareaClass} rows={4} />
          </div>
          <Button type="submit">Adicionar Destino</Button>
        </form>

        <h4 className="text-md font-semibold text-gray-700 mb-3">Destinos Existentes ({destinations.length})</h4>
        <ul className="space-y-3">
          {destinations.map(dest => (
            <li key={dest.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md border">
              <div>
                <span className="font-medium text-gray-800">{dest.name}</span>
                <span className="text-sm text-gray-600"> ({dest.country})</span>
              </div>
              <div className="space-x-2">
                <Button onClick={() => onEditDestination(dest)} variant="secondary" className="text-xs px-2 py-1">Editar</Button>
                <Button onClick={() => { if(window.confirm(`Tem certeza que deseja excluir ${dest.name}?`)) onDeleteDestination(dest.id) }} variant="danger" className="text-xs px-2 py-1">Excluir</Button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminSiteContentPage;