import React from 'react';

const AdminClientsPage: React.FC = () => {
  return (
    <div>
      <h2 className="font-display text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Gerenciamento de Clientes</h2>
      <div className="bg-white p-8 rounded-lg shadow">
        <p className="text-gray-600">
          Aqui você poderá gerenciar perfis de clientes, visualizar históricos de interações,
          reservas anteriores e adicionar notas personalizadas. Ferramentas de busca e filtro
          ajudarão a encontrar clientes específicos rapidamente.
        </p>
        <p className="mt-4 text-teal-600 font-semibold">Funcionalidade em breve!</p>
      </div>
    </div>
  );
};

export default AdminClientsPage;
