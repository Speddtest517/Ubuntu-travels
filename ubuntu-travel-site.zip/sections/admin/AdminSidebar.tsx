import React from 'react';
import { ViewMode } from '../../types';

interface AdminSidebarProps {
  currentView: ViewMode;
  navigate: (view: ViewMode) => void;
}

const DashboardIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className || "h-5 w-5 mr-3"} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const CalendarIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className || "h-5 w-5 mr-3"} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
);

const UsersIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className || "h-5 w-5 mr-3"} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 016-6h6a6 6 0 016 6v1h-3M16 7a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
);

const DocumentTextIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className || "h-5 w-5 mr-3"} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);


const NavItem: React.FC<{
  icon: React.ElementType;
  label: string;
  view: ViewMode;
  currentView: ViewMode;
  navigate: (view: ViewMode) => void;
}> = ({ icon: Icon, label, view, currentView, navigate }) => {
  const isActive = currentView === view;
  return (
    <button
      onClick={() => navigate(view)}
      className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-150 ease-in-out group
        ${isActive ? 'bg-teal-600 text-white shadow-lg' : 'text-gray-300 hover:bg-slate-700 hover:text-white'}`}
      aria-current={isActive ? 'page' : undefined}
    >
      <Icon className={`h-5 w-5 mr-3 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-slate-300'}`} />
      {label}
    </button>
  );
};

const AdminSidebar: React.FC<AdminSidebarProps> = ({ currentView, navigate }) => {
  return (
    <aside className="w-64 bg-slate-800 text-white p-4 space-y-2 flex flex-col shadow-lg">
      <nav className="flex-grow">
        <NavItem icon={DashboardIcon} label="Dashboard" view={ViewMode.AdminDashboard} currentView={currentView} navigate={navigate} />
        <NavItem icon={DocumentTextIcon} label="Conteúdo do Site" view={ViewMode.AdminSiteContent} currentView={currentView} navigate={navigate} />
        <NavItem icon={CalendarIcon} label="Agendamentos" view={ViewMode.AdminAppointments} currentView={currentView} navigate={navigate} />
        <NavItem icon={UsersIcon} label="Clientes" view={ViewMode.AdminClients} currentView={currentView} navigate={navigate} />
      </nav>
      <div className="mt-auto pt-4 border-t border-slate-700">
         <p className="text-xs text-slate-500 text-center">&copy; {new Date().getFullYear()} Ubuntu Travel</p>
      </div>
    </aside>
  );
};

export default AdminSidebar;