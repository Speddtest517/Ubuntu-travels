import React from 'react';

const AdminAppointmentsPage: React.FC = () => {
  return (
    <div>
      <h2 className="font-display text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Gerenciamento de Agendamentos</h2>
      <div className="bg-white p-8 rounded-lg shadow">
        <p className="text-gray-600">
          Esta seção permitirá visualizar, gerenciar e filtrar todos os agendamentos de clientes.
          Incluirá um calendário interativo, visualização de vagas disponíveis/ocupadas e ferramentas
          para confirmações e lembretes.
        </p>
        <p className="mt-4 text-teal-600 font-semibold">Funcionalidade em breve!</p>
      </div>
    </div>
  );
};

export default AdminAppointmentsPage;
