import React from 'react';
import StatsCard from '../../components/common/StatsCard';
import { Stat } from '../../types';

// Icons for stats cards
const GlobeAltIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A11.978 11.978 0 0112 16.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0021 12c0-.778.099-1.533.284-2.253M12 21a9.004 9.004 0 01-8.716-6.747M12 3c2.485 0 4.5 4.03 4.5 9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3" />
  </svg>
);

const CalendarDaysIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5m-9-6h.008v.008H12v-.008zM12 15h.008v.008H12V15zm0 2.25h.008v.008H12v-.008zM9.75 15h.008v.008H9.75V15zm0 2.25h.008v.008H9.75v-.008zM7.5 15h.008v.008H7.5V15zm0 2.25h.008v.008H7.5v-.008zm6.75-4.5h.008v.008h-.008v-.008zm0 2.25h.008v.008h-.008V15zm0 2.25h.008v.008h-.008v-.008zm2.25-4.5h.008v.008H16.5v-.008zm0 2.25h.008v.008H16.5V15z" />
  </svg>
);

const UserGroupIcon: React.FC<{className?: string}> = ({className}) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-3.741-5.58M13.5 19.5A2.25 2.25 0 0111.25 21.75H6.75A2.25 2.25 0 014.5 19.5V6.25A2.25 2.25 0 016.75 4h7.5A2.25 2.25 0 0116.5 6.25v7.5A2.25 2.25 0 0114.25 16h-2.25M13.5 19.5h2.25A2.25 2.25 0 0018 17.25V9A2.25 2.25 0 0015.75 6.75H9.75A2.25 2.25 0 007.5 9v8.25A2.25 2.25 0 009.75 19.5H12M13.5 19.5V13.75M6.75 6.75h.75c.621 0 1.125-.504 1.125-1.125V4.875c0-.621-.504-1.125-1.125-1.125H6.75c-.621 0-1.125.504-1.125 1.125v.75c0 .621.504 1.125 1.125 1.125z" />
</svg>
);


interface AdminDashboardProps {
  totalDestinations: number;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ totalDestinations }) => {
  const stats: Stat[] = [
    { title: 'Total de Destinos', value: totalDestinations, icon: GlobeAltIcon, change: '+2', changeType: 'positive' },
    { title: 'Agendamentos (Mês)', value: '12', icon: CalendarDaysIcon, change: '-3%', changeType: 'negative' }, // Placeholder
    { title: 'Novos Clientes (Mês)', value: '8', icon: UserGroupIcon, change: '+10%', changeType: 'positive' }, // Placeholder
    { title: 'Taxa de Conversão', value: '4.5%', icon: GlobeAltIcon, change: '+0.2%', changeType: 'positive' }, // Placeholder
  ];

  return (
    <div>
      <h2 className="font-display text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Dashboard Administrativo</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <StatsCard key={index} stat={stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Atividade Recente</h3>
          {/* Placeholder para atividade recente */}
          <ul className="space-y-3">
            <li className="text-sm text-gray-600">Novo agendamento para <span className="font-medium text-teal-600">Lisboa</span>.</li>
            <li className="text-sm text-gray-600">Cliente <span className="font-medium text-teal-600">Ana Silva</span> registou-se.</li>
            <li className="text-sm text-gray-600">Descrição do destino <span className="font-medium text-teal-600">Paris</span> atualizada.</li>
          </ul>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Lembretes Rápidos</h3>
          {/* Placeholder para lembretes */}
           <ul className="space-y-3">
            <li className="text-sm text-gray-600">Confirmar agendamento de <span className="font-medium text-teal-600">João Pereira</span>.</li>
            <li className="text-sm text-gray-600">Atualizar pacotes para o Canadá.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
