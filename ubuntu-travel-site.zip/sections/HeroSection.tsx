import React from 'react';
import Button from '../components/common/Button';
import { HeroContentConfig } from '../types';


const HeroSection: React.FC<HeroContentConfig> = ({ title, subtitle, imageUrl }) => {
  return (
    <div 
      className="relative bg-cover bg-center py-24 sm:py-32 lg:py-48" 
      style={{ backgroundImage: `url(${imageUrl})` }}
      role="banner"
      aria-labelledby="hero-title"
    >
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 id="hero-title" className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
          {title}
        </h1>
        <p className="mt-6 text-lg sm:text-xl text-gray-200 max-w-2xl mx-auto">
          {subtitle}
        </p>
        <div className="mt-10">
          <Button 
            onClick={() => { 
              const destinationsSection = document.getElementById('destinations-section');
              if (destinationsSection) {
                destinationsSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="px-8 py-3 text-lg bg-teal-500 hover:bg-teal-600"
            aria-label="Explorar Destinos em Destaque"
          >
            Explorar Destinos
          </Button>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;