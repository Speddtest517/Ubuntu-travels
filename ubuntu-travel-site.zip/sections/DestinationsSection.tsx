import React from 'react';
import { Destination } from '../types';
import DestinationCard from '../components/DestinationCard';

interface DestinationsSectionProps {
  destinations: Destination[];
  onEditDestination: (destination: Destination) => void;
}

const DestinationsSection: React.FC<DestinationsSectionProps> = ({ destinations, onEditDestination }) => {
  return (
    <section id="destinations-section" className="py-12 sm:py-16 lg:py-20 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-gray-800">Destinos em Destaque</h2>
          <p className="mt-4 text-lg text-gray-600">Descubra lugares incríveis selecionados pelos nossos especialistas em viagens.</p>
        </div>
        {destinations.length === 0 ? (
          <p className="text-center text-gray-500">Nenhum destino disponível no momento. Volte em breve!</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.map(destination => (
              <DestinationCard
                key={destination.id}
                destination={destination}
                onEdit={onEditDestination}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default DestinationsSection;