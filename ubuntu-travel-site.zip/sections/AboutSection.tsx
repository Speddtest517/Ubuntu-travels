import React from 'react';
import { AboutContentConfig } from '../types';

interface AboutSectionProps {
  content: AboutContentConfig;
  appName: string;
}

const AboutSection: React.FC<AboutSectionProps> = ({ content, appName }) => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-gray-800">Sobre a {appName}</h2>
          <p 
            className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto"
            dangerouslySetInnerHTML={{ __html: `Criando experiências de viagem únicas e memoráveis, personalizadas para os seus sonhos.`}}
          />
        </div>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src={content.imageUrl} 
              alt={`Equipa ${appName}`}
              className="rounded-lg shadow-xl aspect-[4/3] object-cover"
            />
          </div>
          <div className="space-y-6 text-gray-700">
            <p className="text-xl leading-relaxed" dangerouslySetInnerHTML={{ __html: content.paragraph1.replace('{APP_NAME}', appName) }} />
            <p className="leading-relaxed" dangerouslySetInnerHTML={{ __html: content.paragraph2 }} />
            
            <h3 className="font-display text-2xl font-semibold text-gray-800 pt-4">{content.valuesIntro}</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              {content.valueItems.map(item => (
                <li key={item.title}><span className="font-semibold">{item.title}:</span> {item.description}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;