import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Ensure API_KEY is accessed directly from process.env
// This variable is expected to be set in the environment where the code runs.
const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.error("API_KEY environment variable not set. Gemini API calls will fail.");
  // Optionally, you could throw an error here to halt initialization if the API key is critical.
  // throw new Error("API_KEY environment variable not set.");
}

// Initialize GoogleGenAI only if apiKey is available.
// Operations will fail if apiKey is undefined, but this allows the app to load partially.
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const generateDestinationDescription = async (destinationName: string, countryName?: string): Promise<string> => {
  if (!ai) {
    return Promise.reject(new Error("Cliente da API Gemini não inicializado. Verifique a API_KEY."));
  }
  if (!destinationName.trim()) {
    return Promise.reject(new Error("O nome do destino não pode estar vazio."));
  }

  const prompt = `Escreva uma descrição de viagem envolvente e informativa para ${destinationName}${countryName && countryName.trim() ? `, ${countryName.trim()}` : ''}. Concentre-se nas suas atrações únicas, destaques culturais e no que o torna um destino de viagem desejável. Procure ter cerca de 2-3 parágrafos. Faça com que pareça atraente para um site de agência de viagens.`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", // Use the specified model
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      // No thinkingConfig specified to use default (thinking enabled for higher quality)
      // No systemInstruction needed for this specific prompt, but could be added via config if desired.
    });
    
    const text = response.text;
    if (!text) {
      throw new Error("Nenhum conteúdo de texto recebido da API Gemini.");
    }
    return text.trim();

  } catch (error) {
    console.error("Error generating destination description from Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Erro da API Gemini: ${error.message}`);
    }
    throw new Error("Ocorreu um erro desconhecido ao comunicar com a API Gemini.");
  }
};